import { cn } from "@repo/ui/utils";
import { CreditCard, Package, ArrowRight, TrendingUp } from "lucide-react";

import { prisma } from "@repo/database";
import { auth } from "@/auth";

async function getPayments(status?: string) {
    const session = await auth();
    if (!session?.user) return [];

    const isAdmin = session.user.role === 'ADMIN';
    const isSuperAdmin = session.user.role === 'SUPER_ADMIN';
    const userId = session.user.id;

    let where: any = {};
    if (status) {
        where.status = status;
    }

    if (isAdmin) {
        // Admin only sees payments for cargo they approved
        where.approvedById = userId;
    } else if (!isSuperAdmin) {
        // Regular user only sees their own payments
        where.userId = userId;
    }

    try {
        const payments = await prisma.payment.findMany({
            where,
            include: {
                cargo: true
            },
            orderBy: { createdAt: 'desc' }
        });
        return payments;
    } catch (error) {
        console.error('Error fetching payments:', error);
        return [];
    }
}

const STATUS_META: Record<string, { dot: string; className: string; label: string }> = {
    SUCCESS: { dot: "bg-emerald-500", className: "bg-emerald-50 text-emerald-700 border-emerald-200/60", label: "Success" },
    PENDING: { dot: "bg-amber-400", className: "bg-amber-50 text-amber-700 border-amber-200/60", label: "Pending" },
    FAILED: { dot: "bg-rose-500", className: "bg-rose-50 text-rose-700 border-rose-200/60", label: "Failed" },
    REFUNDED: { dot: "bg-slate-400", className: "bg-slate-50 text-slate-600 border-slate-200/60", label: "Refunded" },
}

function StatusBadge({ status }: { status: string }) {
    const meta = STATUS_META[status] ?? { dot: "bg-slate-400", className: "bg-slate-50 text-slate-500 border-slate-200", label: status }
    return (
        <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border tracking-wide", meta.className)}>
            <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", meta.dot)} />
            {meta.label}
        </span>
    )
}

export async function PaymentList({ status }: { status?: string }) {
    let payments: any[] = []
    try {
        payments = await getPayments(status)
    } catch (e) {
        console.error("Failed to fetch payments", e)
    }

    return (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04)] overflow-hidden">

            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-50">
                <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-emerald-50 rounded-lg flex items-center justify-center">
                        <CreditCard size={13} className="text-emerald-600" strokeWidth={2.5} />
                    </div>
                    <span className="text-[14px] font-extrabold text-slate-800">Transactions</span>
                    <span className="ml-1 px-2 py-0.5 bg-slate-100 text-slate-500 text-[11px] font-extrabold rounded-full">
                        {payments.length}
                    </span>
                </div>
                <span className="inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.15em] text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Live Feed
                </span>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
                <table className="w-full text-[13px]">
                    <thead>
                        <tr>
                            {["Reference", "Cargo Details", "Amount", "Method", "Status", "Date"].map((h, i) => (
                                <th
                                    key={h}
                                    className={cn(
                                        "px-5 py-3.5 text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.12em] bg-slate-50/80 border-b border-slate-100",
                                        i === 5 ? "text-right" : "text-left"
                                    )}
                                >
                                    {h}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                        {payments.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-20 text-center">
                                    <div className="flex flex-col items-center gap-2 text-slate-300">
                                        <CreditCard size={32} strokeWidth={1.5} />
                                        <p className="text-sm font-semibold text-slate-400">No transactions found</p>
                                        <p className="text-[12px]">Payments will appear here once processed</p>
                                    </div>
                                </td>
                            </tr>
                        ) : (
                            payments.map((payment: any) => (
                                <tr key={payment.id} className="group hover:bg-slate-50/60 transition-colors">

                                    {/* Reference */}
                                    <td className="px-5 py-4 whitespace-nowrap">
                                        <div className="flex items-center gap-2">
                                            <div className="h-4 w-[2px] bg-indigo-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                                            <span className="font-mono text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                                                {payment.transactionReference || `#${payment.id.slice(0, 8).toUpperCase()}`}
                                            </span>
                                        </div>
                                    </td>

                                    {/* Cargo Details */}
                                    <td className="px-5 py-4 max-w-[220px]">
                                        <div className="flex flex-col gap-0.5">
                                            <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-700">
                                                <Package size={11} className="text-slate-300 shrink-0" />
                                                <span className="truncate">{payment.cargo?.cargoType || "Cargo Shipment"}</span>
                                            </div>
                                            {payment.cargo?.fromAddress && (
                                                <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium pl-4">
                                                    <span className="truncate max-w-[80px]">{payment.cargo.fromAddress}</span>
                                                    <ArrowRight size={9} className="shrink-0" />
                                                    <span className="truncate max-w-[80px]">{payment.cargo.toAddress}</span>
                                                </div>
                                            )}
                                        </div>
                                    </td>

                                    {/* Amount */}
                                    <td className="px-5 py-4 whitespace-nowrap">
                                        <span className="text-[13px] font-extrabold text-slate-900 tabular-nums">
                                            TZS {payment.amount.toLocaleString()}
                                        </span>
                                    </td>

                                    {/* Method */}
                                    <td className="px-5 py-4">
                                        {payment.paymentMethod ? (
                                            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                                                {payment.paymentMethod}
                                            </span>
                                        ) : (
                                            <span className="text-slate-200 text-[11px]">—</span>
                                        )}
                                    </td>

                                    {/* Status */}
                                    <td className="px-5 py-4">
                                        <StatusBadge status={payment.status} />
                                    </td>

                                    {/* Date */}
                                    <td className="px-5 py-4 text-right whitespace-nowrap">
                                        <div className="flex flex-col items-end">
                                            <span className="text-[12px] font-bold text-slate-700 tabular-nums">
                                                {new Date(payment.createdAt).toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}
                                            </span>
                                            <span className="text-[10px] text-slate-400 font-medium tabular-nums">
                                                {new Date(payment.createdAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    )
}

