'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
    CheckCircle2, XCircle, Eye, Loader2, TruckIcon,
    Compass, MapPin, ArrowUpRight, Package, SlidersHorizontal, Calendar
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { ViewToggle, ViewType } from '@/components/ui/view-toggle'
import { CreateCargoModal } from './create-cargo-modal'

// ── Status config ──────────────────────────────────────────────────────────────

const STATUS_META: Record<string, { label: string; dot: string; className: string }> = {
    PENDING:         { label: 'Pending',          dot: 'bg-amber-400',   className: 'bg-amber-50 text-amber-700 border-amber-200/60' },
    APPROVED:        { label: 'Approved',          dot: 'bg-blue-500',    className: 'bg-blue-50 text-blue-700 border-blue-200/60' },
    PAYMENT_PENDING: { label: 'Awaiting Payment',  dot: 'bg-violet-500',  className: 'bg-violet-50 text-violet-700 border-violet-200/60' },
    PAID:            { label: 'Paid',              dot: 'bg-emerald-500', className: 'bg-emerald-50 text-emerald-700 border-emerald-200/60' },
    IN_TRANSIT:      { label: 'In Transit',        dot: 'bg-indigo-500',  className: 'bg-indigo-50 text-indigo-700 border-indigo-200/60' },
    DELAYED:         { label: 'Delayed',           dot: 'bg-rose-500',    className: 'bg-rose-50 text-rose-700 border-rose-200/60' },
    COMPLETED:       { label: 'Completed',         dot: 'bg-slate-400',   className: 'bg-slate-50 text-slate-600 border-slate-200/60' },
    REJECTED:        { label: 'Rejected',          dot: 'bg-rose-500',    className: 'bg-rose-50 text-rose-700 border-rose-200/60' },
}

function StatusBadge({ status }: { status: string }) {
    const meta = STATUS_META[status] ?? { label: status, dot: 'bg-slate-400', className: 'bg-slate-50 text-slate-600 border-slate-200' }
    return (
        <span className={cn('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border tracking-wide', meta.className)}>
            <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', meta.dot)} />
            {meta.label}
        </span>
    )
}

// ── Types ──────────────────────────────────────────────────────────────────────

export interface CargoItem {
    id: string
    fromAddress: string
    toAddress: string
    serviceType: string
    cargoType: string
    cargoSize: string
    status: string
    wagonType?: string | null
    amount?: number | null
    receiverName: string
    receiverPhone?: string
    peopleNeeded?: number
    createdAt: string
    user?: { name: string; email: string; phone?: string | null } | null
    payment?: { status: string; transactionReference?: string | null } | null
}

// ── Approve Modal ──────────────────────────────────────────────────────────────

function ApproveModal({ cargo, onClose, onSuccess }: { cargo: CargoItem; onClose: () => void; onSuccess: () => void }) {
    const [amount, setAmount] = useState(cargo.amount?.toString() ?? '')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')

    const handleApprove = async () => {
        if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
            setError('Please enter a valid amount.')
            return
        }
        setLoading(true)
        setError('')
        try {
            const res = await fetch(`/api/cargo/${cargo.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'APPROVED', amount: Number(amount) }),
            })
            const data = await res.json()
            if (!res.ok) throw new Error(data.error ?? 'Failed to approve')
            onSuccess(); onClose()
        } catch (e: any) {
            setError(e.message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-[2px]" onClick={onClose} />
            <div className="relative z-10 bg-white rounded-2xl shadow-[0_24px_64px_rgba(0,0,0,0.14)] w-full max-w-md overflow-hidden">
                {/* Header strip */}
                <div className="h-1 bg-gradient-to-r from-emerald-400 to-emerald-500" />
                <div className="px-6 pt-5 pb-4 border-b border-slate-50">
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-emerald-50 rounded-xl flex items-center justify-center shrink-0">
                            <CheckCircle2 size={17} className="text-emerald-600" />
                        </div>
                        <div>
                            <h2 className="text-[15px] font-extrabold text-slate-900 tracking-tight">Approve Request</h2>
                            <p className="text-[12px] text-slate-400 font-mono mt-0.5">#{cargo.id.slice(-8).toUpperCase()}</p>
                        </div>
                    </div>
                </div>

                <div className="px-6 py-5 space-y-4">
                    {/* Route summary */}
                    <div className="bg-slate-50 rounded-xl p-4">
                        <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-2.5 text-[13px] font-semibold text-slate-700">
                                <div className="w-2 h-2 rounded-full bg-indigo-500 shrink-0" />
                                {cargo.fromAddress}
                            </div>
                            <div className="ml-[3px] h-4 border-l-2 border-dashed border-slate-200" />
                            <div className="flex items-center gap-2.5 text-[13px] font-medium text-slate-500">
                                <div className="w-2 h-2 rounded-full bg-slate-300 shrink-0" />
                                {cargo.toAddress}
                            </div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-slate-100 flex gap-4 text-[11px]">
                            <span className="text-slate-400 uppercase tracking-wider font-bold">Service</span>
                            <span className="font-bold text-slate-700">{cargo.serviceType}</span>
                        </div>
                    </div>

                    <div>
                        <label className="block text-[11px] font-extrabold text-slate-500 uppercase tracking-wider mb-2">
                            Payment Amount (TZS) *
                        </label>
                        <div className="relative">
                            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[12px] font-extrabold text-slate-400">TZS</span>
                            <input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="0"
                                className="w-full pl-14 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white transition-colors"
                            />
                        </div>
                    </div>

                    {error && <p className="text-[12px] text-rose-600 bg-rose-50 px-3 py-2 rounded-lg font-semibold">{error}</p>}
                </div>

                <div className="px-6 pb-6 flex gap-2.5">
                    <button onClick={onClose} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-[13px] font-bold text-slate-500 hover:bg-slate-50 transition-colors">
                        Cancel
                    </button>
                    <button
                        onClick={handleApprove}
                        disabled={loading}
                        className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white rounded-xl text-[13px] font-extrabold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-200"
                    >
                        {loading ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                        Approve & Set Amount
                    </button>
                </div>
            </div>
        </div>
    )
}

// ── Reject Modal ───────────────────────────────────────────────────────────────

function RejectModal({ cargo, onClose, onSuccess }: { cargo: CargoItem; onClose: () => void; onSuccess: () => void }) {
    const [reason, setReason] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')

    const handleReject = async () => {
        if (!reason.trim()) { setError('Please provide a rejection reason.'); return }
        setLoading(true); setError('')
        try {
            const res = await fetch(`/api/cargo/${cargo.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'REJECTED', reason }),
            })
            const data = await res.json()
            if (!res.ok) throw new Error(data.error ?? 'Failed to reject')
            onSuccess(); onClose()
        } catch (e: any) {
            setError(e.message)
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-[2px]" onClick={onClose} />
            <div className="relative z-10 bg-white rounded-2xl shadow-[0_24px_64px_rgba(0,0,0,0.14)] w-full max-w-md overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-rose-400 to-rose-500" />
                <div className="px-6 pt-5 pb-4 border-b border-slate-50">
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-rose-50 rounded-xl flex items-center justify-center shrink-0">
                            <XCircle size={17} className="text-rose-600" />
                        </div>
                        <div>
                            <h2 className="text-[15px] font-extrabold text-slate-900 tracking-tight">Reject Request</h2>
                            <p className="text-[12px] text-slate-400 font-mono mt-0.5">#{cargo.id.slice(-8).toUpperCase()}</p>
                        </div>
                    </div>
                </div>

                <div className="px-6 py-5 space-y-3">
                    <label className="block text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                        Reason for rejection *
                    </label>
                    <textarea
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        rows={4}
                        placeholder="Provide a clear reason for the customer..."
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-[13px] focus:outline-none focus:ring-2 focus:ring-rose-400 focus:bg-white resize-none transition-colors"
                    />
                    {error && <p className="text-[12px] text-rose-600 bg-rose-50 px-3 py-2 rounded-lg font-semibold">{error}</p>}
                </div>

                <div className="px-6 pb-6 flex gap-2.5">
                    <button onClick={onClose} className="flex-1 py-2.5 border border-slate-200 rounded-xl text-[13px] font-bold text-slate-500 hover:bg-slate-50 transition-colors">
                        Cancel
                    </button>
                    <button
                        onClick={handleReject}
                        disabled={loading}
                        className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white rounded-xl text-[13px] font-extrabold transition-colors flex items-center justify-center gap-2"
                    >
                        {loading ? <Loader2 size={14} className="animate-spin" /> : <XCircle size={14} />}
                        Reject Request
                    </button>
                </div>
            </div>
        </div>
    )
}

// ── Action Button ──────────────────────────────────────────────────────────────

function ActionBtn({ onClick, title, icon, className }: { onClick: () => void; title: string; icon: React.ReactNode; className: string }) {
    return (
        <button title={title} onClick={onClick} className={cn('w-7 h-7 rounded-lg flex items-center justify-center transition-colors', className)}>
            {icon}
        </button>
    )
}

// ── Main Component ─────────────────────────────────────────────────────────────

export function CargoAdminTable({ initialItems }: { initialItems: CargoItem[] }) {
    const router = useRouter()
    const items = initialItems
    const [view, setView] = useState<ViewType>('list')
    const [approveTarget, setApproveTarget] = useState<CargoItem | null>(null)
    const [rejectTarget, setRejectTarget] = useState<CargoItem | null>(null)
    const refresh = useCallback(() => router.refresh(), [router])

    return (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04)] overflow-hidden">

            {/* Table Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-50">
                <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-indigo-50 rounded-lg flex items-center justify-center">
                        <TruckIcon size={13} className="text-indigo-500" strokeWidth={2.5} />
                    </div>
                    <span className="text-[14px] font-extrabold text-slate-800">Cargo Requests</span>
                    <span className="ml-1 px-2 py-0.5 bg-slate-100 text-slate-500 text-[11px] font-extrabold rounded-full">
                        {items.length}
                    </span>
                </div>
                <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl px-3 py-1.5 focus-within:ring-2 focus-within:ring-indigo-400 focus-within:bg-white transition-all">
                        <Calendar size={13} className="text-slate-400" />
                        <input 
                            type="date" 
                            className="bg-transparent border-none text-[12px] font-bold text-slate-600 focus:outline-none"
                            onChange={(e) => {
                                const params = new URLSearchParams(window.location.search)
                                if (e.target.value) params.set('startDate', e.target.value)
                                else params.delete('startDate')
                                router.push(`${window.location.pathname}?${params.toString()}`)
                            }}
                        />
                        <span className="text-slate-300 mx-1">—</span>
                        <input 
                            type="date" 
                            className="bg-transparent border-none text-[12px] font-bold text-slate-600 focus:outline-none"
                            onChange={(e) => {
                                const params = new URLSearchParams(window.location.search)
                                if (e.target.value) params.set('endDate', e.target.value)
                                else params.delete('endDate')
                                router.push(`${window.location.pathname}?${params.toString()}`)
                            }}
                        />
                    </div>
                    <ViewToggle view={view} onChange={setView} />
                    <CreateCargoModal />
                </div>
            </div>

            {/* Empty state */}
            {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-24 text-slate-300 gap-3">
                    <Package size={36} strokeWidth={1.5} />
                    <p className="text-sm font-semibold text-slate-400">No cargo requests found</p>
                    <p className="text-[12px] text-slate-300">New requests will appear here once created</p>
                </div>
            ) : view === 'list' ? (
                <div className="overflow-x-auto">
                    <table className="w-full text-[13px]">
                        <thead>
                            <tr>
                                {['Request ID', 'Customer', 'Route', 'Service / Type', 'Wagon', 'Amount', 'Status', ''].map((h, i) => (
                                    <th
                                        key={h + i}
                                        className={cn(
                                            'px-5 py-3.5 text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.12em] bg-slate-50/80 border-b border-slate-100',
                                            i === 6 ? 'text-right w-28' : 'text-left'
                                        )}
                                    >
                                        {h}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {items.map((item) => {
                                const canApprove = item.status === 'PENDING'
                                const canReject = ['PENDING', 'APPROVED', 'PAYMENT_PENDING'].includes(item.status)

                                return (
                                    <tr key={item.id} className="group hover:bg-slate-50/60 transition-colors">

                                        {/* ID */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            <span className="font-mono text-[11px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">
                                                #{item.id.slice(-8).toUpperCase()}
                                            </span>
                                        </td>

                                        {/* Customer */}
                                        <td className="px-5 py-4">
                                            {item.user ? (
                                                <div>
                                                    <p className="font-bold text-slate-800 text-[13px] leading-tight">{item.user.name}</p>
                                                    <p className="text-[11px] text-slate-400 font-medium mt-0.5">{item.user.phone ?? item.user.email}</p>
                                                </div>
                                            ) : <span className="text-slate-300">—</span>}
                                        </td>

                                        {/* Route */}
                                        <td className="px-5 py-4 max-w-[200px]">
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-1.5 text-[12px] font-semibold text-slate-700">
                                                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                                                    <span className="truncate">{item.fromAddress}</span>
                                                </div>
                                                <div className="flex items-center gap-1.5 text-[12px] text-slate-400">
                                                    <div className="w-1.5 h-1.5 rounded-full bg-slate-200 shrink-0" />
                                                    <span className="truncate">{item.toAddress}</span>
                                                </div>
                                            </div>
                                        </td>

                                        {/* Service */}
                                        <td className="px-5 py-4">
                                            <div>
                                                <p className="text-[12px] font-bold text-slate-700 uppercase tracking-wide">{item.serviceType}</p>
                                                <p className="text-[11px] text-slate-400 font-medium mt-0.5">{item.cargoType} · {item.cargoSize}</p>
                                            </div>
                                        </td>

                                        {/* Wagon */}
                                        <td className="px-5 py-4">
                                            {item.wagonType ? (
                                                <span className="text-[11px] font-bold text-slate-600 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded-md uppercase tracking-tight">
                                                    {item.wagonType}
                                                </span>
                                            ) : <span className="text-slate-300">—</span>}
                                        </td>

                                        {/* Amount */}
                                        <td className="px-5 py-4 whitespace-nowrap">
                                            {item.amount != null ? (
                                                <span className="text-[13px] font-extrabold text-slate-900 tabular-nums">
                                                    TZS {Number(item.amount).toLocaleString()}
                                                </span>
                                            ) : (
                                                <span className="text-[12px] text-slate-300 font-medium italic">Not set</span>
                                            )}
                                        </td>

                                        {/* Status */}
                                        <td className="px-5 py-4">
                                            <StatusBadge status={item.status} />
                                        </td>

                                        {/* Actions */}
                                        <td className="px-5 py-4">
                                            <div className="flex items-center justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-all duration-150">
                                                <ActionBtn
                                                    onClick={() => router.push(`/cargo/${item.id}`)}
                                                    title="View details"
                                                    icon={<Eye size={13} />}
                                                    className="text-slate-400 hover:text-indigo-600 hover:bg-indigo-50"
                                                />
                                                {canApprove && (
                                                    <ActionBtn
                                                        onClick={() => setApproveTarget(item)}
                                                        title="Approve"
                                                        icon={<CheckCircle2 size={13} />}
                                                        className="text-slate-400 hover:text-emerald-600 hover:bg-emerald-50"
                                                    />
                                                )}
                                                {canReject && (
                                                    <ActionBtn
                                                        onClick={() => setRejectTarget(item)}
                                                        title="Reject"
                                                        icon={<XCircle size={13} />}
                                                        className="text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                                                    />
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            ) : (
                // ── Grid View ──────────────────────────────────────────────────
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-6">
                    {items.map((item) => (
                        <div
                            key={item.id}
                            onClick={() => router.push(`/cargo/${item.id}`)}
                            className="group relative bg-white rounded-xl border border-slate-100 p-4 shadow-[0_1px_3px_rgba(0,0,0,0.04)] hover:shadow-[0_6px_20px_rgba(0,0,0,0.07)] hover:-translate-y-0.5 cursor-pointer transition-all duration-200 flex flex-col gap-3.5"
                        >
                            {/* Top row */}
                            <div className="flex items-start justify-between">
                                <span className="font-mono text-[10px] font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                                    #{item.id.slice(-8).toUpperCase()}
                                </span>
                                <StatusBadge status={item.status} />
                            </div>

                            {/* Route */}
                            <div className="flex flex-col gap-1.5 relative pl-3">
                                <div className="absolute left-0.5 top-1 bottom-1 w-[1.5px] bg-slate-100 rounded-full" />
                                <div>
                                    <p className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400 mb-0.5">From</p>
                                    <p className="text-[12px] font-bold text-slate-700 line-clamp-1">{item.fromAddress}</p>
                                </div>
                                <div>
                                    <p className="text-[9px] font-extrabold uppercase tracking-widest text-slate-400 mb-0.5">To</p>
                                    <p className="text-[12px] font-bold text-slate-700 line-clamp-1">{item.toAddress}</p>
                                </div>
                            </div>

                            {/* Footer */}
                            <div className="pt-3 border-t border-slate-50 flex items-center justify-between">
                                <div>
                                    <p className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest mb-0.5">Amount</p>
                                    <p className="text-[12px] font-extrabold text-slate-900">
                                        {item.amount != null ? `TZS ${Number(item.amount).toLocaleString()}` : <span className="text-slate-300 font-medium italic text-[11px]">Pending</span>}
                                    </p>
                                </div>
                                <ArrowUpRight size={14} className="text-slate-300 group-hover:text-indigo-500 transition-colors" />
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Modals */}
            {approveTarget && (
                <ApproveModal cargo={approveTarget} onClose={() => setApproveTarget(null)} onSuccess={refresh} />
            )}
            {rejectTarget && (
                <RejectModal cargo={rejectTarget} onClose={() => setRejectTarget(null)} onSuccess={refresh} />
            )}
        </div>
    )
}