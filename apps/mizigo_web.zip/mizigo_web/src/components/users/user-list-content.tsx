"use client";

import { useState } from "react";
import { Users, Calendar, Mail, Shield, User as UserIcon, ArrowUpRight } from "lucide-react";
import { CreateUserModal } from "./create-user-modal";
import { ViewToggle, ViewType } from "@/components/ui/view-toggle";
import { cn } from "@/lib/utils";

const ROLE_META: Record<string, { className: string }> = {
    SUPER_ADMIN: { className: "bg-violet-50 text-violet-700 border-violet-200/60" },
    ADMIN:       { className: "bg-indigo-50 text-indigo-700 border-indigo-200/60" },
    OPERATOR:    { className: "bg-amber-50 text-amber-700 border-amber-200/60" },
    AGENT:       { className: "bg-emerald-50 text-emerald-700 border-emerald-200/60" },
    USER:        { className: "bg-slate-50 text-slate-600 border-slate-200/60" },
}

function RoleBadge({ role }: { role: string }) {
    const label = role || "USER"
    const meta = ROLE_META[label] || ROLE_META["USER"]!
    return (
        <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border tracking-wide", meta.className)}>
            <Shield size={10} strokeWidth={2.5} />
            {label}
        </span>
    )
}

// Deterministic avatar colour from name
function avatarColor(name: string) {
    const palette = [
        "bg-indigo-100 text-indigo-600",
        "bg-violet-100 text-violet-600",
        "bg-sky-100 text-sky-600",
        "bg-emerald-100 text-emerald-600",
        "bg-amber-100 text-amber-600",
        "bg-rose-100 text-rose-600",
    ]
    const idx = (name?.charCodeAt(0) ?? 0) % palette.length
    return palette[idx]
}

function Avatar({ name, size = "md" }: { name: string; size?: "sm" | "md" | "lg" }) {
    const dim = size === "lg" ? "w-12 h-12 text-base" : size === "sm" ? "w-7 h-7 text-[11px]" : "w-9 h-9 text-[13px]"
    return (
        <div className={cn("rounded-xl flex items-center justify-center font-extrabold shrink-0", dim, avatarColor(name))}>
            {name?.charAt(0).toUpperCase() ?? "?"}
        </div>
    )
}

interface UserListContentProps { 
    users: any[] 
    currentUserRole?: string
}

export function UserListContent({ users, currentUserRole }: UserListContentProps) {
    const [view, setView] = useState<ViewType>("list");

    return (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04)] overflow-hidden">

            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-50">
                <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-indigo-50 rounded-lg flex items-center justify-center">
                        <Users size={13} className="text-indigo-500" strokeWidth={2.5} />
                    </div>
                    <span className="text-[14px] font-extrabold text-slate-800">User Management</span>
                    <span className="ml-1 px-2 py-0.5 bg-slate-100 text-slate-500 text-[11px] font-extrabold rounded-full">
                        {users.length}
                    </span>
                </div>
                <div className="flex items-center gap-3">
                    <ViewToggle view={view} onChange={setView} />
                    <CreateUserModal currentUserRole={currentUserRole} />
                </div>
            </div>

            {/* Empty state */}
            {users.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-24 gap-3 text-slate-300">
                    <UserIcon size={36} strokeWidth={1.5} />
                    <p className="text-sm font-semibold text-slate-400">No users found</p>
                    <p className="text-[12px]">Users will appear here once added</p>
                </div>
            ) : view === "list" ? (

                // ── List view ──────────────────────────────────────────────────
                <div className="overflow-x-auto">
                    <table className="w-full text-[13px]">
                        <thead>
                            <tr>
                                {["User", "Email", "Role", "Registered"].map((h, i) => (
                                    <th
                                        key={h}
                                        className="px-5 py-3.5 text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.12em] bg-slate-50/80 border-b border-slate-100 text-left"
                                    >
                                        {h}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                            {users.map((user: any) => (
                                <tr key={user.id} className="group hover:bg-slate-50/60 transition-colors">

                                    {/* User */}
                                    <td className="px-5 py-4">
                                        <div className="flex items-center gap-3">
                                            <Avatar name={user.name} />
                                            <span className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                                                {user.name}
                                            </span>
                                        </div>
                                    </td>

                                    {/* Email */}
                                    <td className="px-5 py-4">
                                        <div className="flex items-center gap-1.5 text-[12px] text-slate-400 font-medium">
                                            <Mail size={11} className="text-slate-300 shrink-0" />
                                            {user.email}
                                        </div>
                                    </td>

                                    {/* Role */}
                                    <td className="px-5 py-4">
                                        <RoleBadge role={user.role?.name || "USER"} />
                                    </td>

                                    {/* Registered */}
                                    <td className="px-5 py-4">
                                        <div className="flex flex-col">
                                            <span className="text-[12px] font-bold text-slate-700 tabular-nums">
                                                {new Date(user.createdAt).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
                                            </span>
                                            <span className="text-[10px] text-slate-400 font-medium mt-0.5">
                                                {new Date(user.createdAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

            ) : (

                // ── Grid view ──────────────────────────────────────────────────
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-6">
                    {users.map((user: any) => (
                        <div
                            key={user.id}
                            className="group bg-white rounded-xl border border-slate-100 p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] hover:shadow-[0_6px_20px_rgba(0,0,0,0.07)] hover:-translate-y-0.5 transition-all duration-200 flex flex-col items-center text-center gap-3.5"
                        >
                            {/* Avatar */}
                            <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-extrabold", avatarColor(user.name))}>
                                {user.name?.charAt(0).toUpperCase() ?? "?"}
                            </div>

                            {/* Info */}
                            <div>
                                <p className="font-extrabold text-slate-900 text-[14px] leading-tight group-hover:text-indigo-600 transition-colors">
                                    {user.name}
                                </p>
                                <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400 font-medium mt-1">
                                    <Mail size={10} />
                                    <span className="truncate max-w-[160px]">{user.email}</span>
                                </div>
                            </div>

                            {/* Role */}
                            <RoleBadge role={user.role?.name || "USER"} />

                            {/* Footer */}
                            <div className="w-full pt-3 border-t border-slate-50 flex items-center justify-between">
                                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    <Calendar size={10} className="opacity-50" />
                                    {new Date(user.createdAt).toLocaleDateString("en-GB", { month: "short", year: "numeric" })}
                                </div>
                                <ArrowUpRight size={13} className="text-slate-200 group-hover:text-indigo-400 transition-colors" />
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}
