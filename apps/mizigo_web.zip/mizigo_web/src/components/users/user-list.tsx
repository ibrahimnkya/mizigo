import { UserListContent } from "@/components/users/user-list-content";
import { auth } from "@/auth";

async function getUsers() {
    const base = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const res = await fetch(`${base}/api/users`, { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
}

export async function UserList() {
    const session = await auth();
    const currentUserRole = session?.user?.role || "USER";
    
    let users = [];
    try { users = await getUsers() } catch (e) { console.error("Failed to fetch users", e) }
    
    return <UserListContent users={users} currentUserRole={currentUserRole} />
}