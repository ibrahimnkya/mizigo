import type { NextAuthConfig } from 'next-auth';

export const authConfig: NextAuthConfig = {
    pages: {
        signIn: '/login',
    },
    callbacks: {
        authorized({ auth, request: { nextUrl } }) {
            const isLoggedIn = !!auth?.user;
            const isLoginPage = nextUrl.pathname.startsWith('/login');
            const userRole = auth?.user?.role;

            if (isLoginPage) {
                if (isLoggedIn) return Response.redirect(new URL('/dashboard', nextUrl));
                return true;
            }

            // Protect all other routes
            if (!isLoggedIn) return false;

            // Role-based authorization
            const pathname = nextUrl.pathname;

            // SUPER_ADMIN only routes
            const superAdminRoutes = ['/payments', '/admins', '/reports', '/settings', '/audit', '/users'];
            if (superAdminRoutes.some(route => pathname.startsWith(route)) && userRole !== 'SUPER_ADMIN') {
                // Special check for pages shared with ADMIN
                const isSharedReport = pathname === '/reports' || pathname.startsWith('/reports/volume') || pathname.startsWith('/reports/turnaround');
                const sharedRoutes = ['/notifications', '/users'];
                if ((sharedRoutes.some(route => pathname.startsWith(route)) || isSharedReport) && (userRole === 'ADMIN' || userRole === 'SUPER_ADMIN')) return true;


                // If it's a shared child route like /cargo or /dashboard, we handle it separately
                if (pathname.startsWith('/cargo') || pathname.startsWith('/dashboard')) return true;

                return Response.redirect(new URL('/dashboard', nextUrl));
            }

            // ADMIN only routes
            const adminOnlyRoutes = ['/my-payments', '/performance'];
            if (adminOnlyRoutes.some(route => pathname.startsWith(route)) && userRole !== 'ADMIN') {
                return Response.redirect(new URL('/dashboard', nextUrl));
            }

            return true;
        },
        async jwt({ token, user }) {
            if (user) {
                token.id = user.id;
                token.role = user.role;
                token.createdAt = (user as any).createdAt;
                token.permissions = (user as any).permissions;
            }
            return token;
        },
        async session({ session, token }) {
            if (token && session.user) {
                session.user.id = token.id as string;
                session.user.role = token.role as string;
                session.user.createdAt = token.createdAt as string;
                session.user.permissions = token.permissions as string[];
            }
            return session;
        },

    },
    providers: [], // Add providers with an empty array for now
} satisfies NextAuthConfig;
