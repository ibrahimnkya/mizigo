import { CargoList } from '@/components/cargo/cargo-list'
import { Panel } from '@/components/dashboard/dashboard-shell'
import { CreditCard } from 'lucide-react'

export default function MyPaymentsAllPage() {
    return (
        <Panel 
            title="All Payments" 
            icon={CreditCard} 
            iconColor="text-slate-400"
        >
            <CargoList />
        </Panel>
    )
}
