import { CargoList } from '@/components/cargo/cargo-list'
import { Panel } from '@/components/dashboard/dashboard-shell'
import { CreditCard } from 'lucide-react'

export default function MyPaymentsPayAsYouGoPage() {
    return (
        <Panel 
            title="Pay as you Go" 
            icon={CreditCard} 
            iconColor="text-indigo-400"
        >
            <CargoList receiverPays={false} />
        </Panel>
    )
}
