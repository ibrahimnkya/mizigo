import { CargoList } from '@/components/cargo/cargo-list'
import { Panel } from '@/components/dashboard/dashboard-shell'
import { CreditCard } from 'lucide-react'

export default function MyPaymentsPendingPage() {
    return (
        <Panel 
            title="To Pay (Awaiting Payments)" 
            icon={CreditCard} 
            iconColor="text-amber-400"
        >
            <CargoList receiverPays={true} />
        </Panel>
    )
}
