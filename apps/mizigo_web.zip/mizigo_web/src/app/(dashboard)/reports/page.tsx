import Link from "next/link";
import { TrendingUp, Package2, Timer, ArrowUpRight } from "lucide-react";

const reportCards = [
    {
        title: "Revenue Report",
        description: "View detailed financial performance and projections.",
        href: "/reports/revenue",
        icon: TrendingUp,
        accent: "#10b981",
        accentBg: "bg-emerald-50",
        accentText: "text-emerald-600",
        tag: "Financial",
    },
    {
        title: "Cargo Volume",
        description: "Analysis of shipment quantities and station activity.",
        href: "/reports/volume",
        icon: Package2,
        accent: "#3b82f6",
        accentBg: "bg-blue-50",
        accentText: "text-blue-600",
        tag: "Operations",
    },
    {
        title: "Approval Speeds",
        description: "Monitor turnaround times and operational efficiency.",
        href: "/reports/turnaround",
        icon: Timer,
        accent: "#f59e0b",
        accentBg: "bg-amber-50",
        accentText: "text-amber-600",
        tag: "Performance",
    },
]

export default function ReportsPage() {
    return (
        <div className="min-h-screen bg-[#f8f9fb]">
            <div className="max-w-[1520px] mx-auto px-6 lg:px-10 py-10 flex flex-col gap-8">

                {/* Header */}
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
                            Analytics
                        </span>
                    </div>
                    <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Reports & Analytics</h1>
                    <p className="text-sm text-slate-400 font-medium mt-0.5">Comprehensive overview of system performance and metrics.</p>
                </div>

                {/* Cards */}
                <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                    {reportCards.map((report) => (
                        <Link key={report.title} href={report.href} className="group">
                            <div className="relative bg-white rounded-2xl border border-slate-100 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200 overflow-hidden h-full flex flex-col gap-5">

                                {/* Subtle corner glow */}
                                <div
                                    className="absolute -top-8 -right-8 w-28 h-28 rounded-full blur-2xl opacity-[0.07] pointer-events-none"
                                    style={{ backgroundColor: report.accent }}
                                />

                                {/* Top row */}
                                <div className="flex items-start justify-between">
                                    <div
                                        className="w-10 h-10 rounded-xl flex items-center justify-center"
                                        style={{ backgroundColor: `${report.accent}18` }}
                                    >
                                        <report.icon size={18} style={{ color: report.accent }} strokeWidth={2} />
                                    </div>
                                    <span className={`text-[9px] font-extrabold uppercase tracking-[0.15em] px-2 py-1 rounded-full ${report.accentBg} ${report.accentText}`}>
                                        {report.tag}
                                    </span>
                                </div>

                                {/* Content */}
                                <div className="flex-1">
                                    <h3 className="text-[15px] font-extrabold text-slate-900 tracking-tight group-hover:text-indigo-600 transition-colors">
                                        {report.title}
                                    </h3>
                                    <p className="text-[12px] text-slate-400 font-medium mt-1.5 leading-relaxed">
                                        {report.description}
                                    </p>
                                </div>

                                {/* CTA */}
                                <div className="flex items-center gap-1 text-[11px] font-extrabold text-indigo-500 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all duration-200">
                                    View report <ArrowUpRight size={12} />
                                </div>

                                {/* Bottom accent line */}
                                <div
                                    className="absolute bottom-0 left-5 right-5 h-[2px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                                    style={{ backgroundColor: report.accent }}
                                />
                            </div>
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    )
}

