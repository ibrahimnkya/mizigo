import { ShieldCheck, Activity, User as UserIcon, Clock, FileText } from "lucide-react"
import { cn } from "@/lib/utils"

async function getAuditLogs() {
    const res = await fetch("http://localhost:3000/api/audit", { cache: "no-store" })
    if (!res.ok) return []
    return res.json()
}

// Colour-code action verbs
function actionMeta(action: string) {
    const a = action?.toUpperCase()
    if (a?.includes("CREATE") || a?.includes("ADD"))    return { className: "bg-emerald-50 text-emerald-700 border-emerald-200/60", dot: "bg-emerald-500" }
    if (a?.includes("UPDATE") || a?.includes("EDIT"))   return { className: "bg-sky-50 text-sky-700 border-sky-200/60",         dot: "bg-sky-500" }
    if (a?.includes("DELETE") || a?.includes("REMOVE")) return { className: "bg-rose-50 text-rose-700 border-rose-200/60",       dot: "bg-rose-500" }
    if (a?.includes("LOGIN")  || a?.includes("AUTH"))   return { className: "bg-violet-50 text-violet-700 border-violet-200/60", dot: "bg-violet-500" }
    if (a?.includes("APPROVE"))                         return { className: "bg-indigo-50 text-indigo-700 border-indigo-200/60", dot: "bg-indigo-500" }
    if (a?.includes("REJECT"))                          return { className: "bg-amber-50 text-amber-700 border-amber-200/60",    dot: "bg-amber-500" }
    return { className: "bg-slate-50 text-slate-600 border-slate-200/60", dot: "bg-slate-400" }
}

function ActionBadge({ action }: { action: string }) {
    const { className, dot } = actionMeta(action)
    return (
        <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border tracking-wide whitespace-nowrap", className)}>
            <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", dot)} />
            {action}
        </span>
    )
}

import { auth } from "@/auth"
import { redirect } from "next/navigation"

export default async function AuditLogsPage() {
    const session = await auth()
    if (session?.user?.role !== 'SUPER_ADMIN') {
        redirect("/dashboard")
    }

    const logs = await getAuditLogs()

    return (
        <div className="min-h-screen bg-[#f8f9fb]">
            <div className="max-w-[1520px] mx-auto px-6 lg:px-10 py-10 flex flex-col gap-8">

                {/* Header */}
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full">
                            Security
                        </span>
                    </div>
                    <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Audit Logs</h1>
                    <p className="text-sm text-slate-400 font-medium mt-0.5">
                        Traceable history of system security and administrative actions.
                    </p>
                </div>

                {/* Table card */}
                <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_1px_3px_rgba(0,0,0,0.04)] overflow-hidden">

                    {/* Card header */}
                    <div className="flex items-center justify-between px-6 py-4 border-b border-slate-50">
                        <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 bg-sky-50 rounded-lg flex items-center justify-center">
                                <ShieldCheck size={13} className="text-sky-600" strokeWidth={2.5} />
                            </div>
                            <span className="text-[14px] font-extrabold text-slate-800">System Activity</span>
                            {logs.length > 0 && (
                                <span className="ml-1 px-2 py-0.5 bg-slate-100 text-slate-500 text-[11px] font-extrabold rounded-full">
                                    {logs.length}
                                </span>
                            )}
                        </div>
                        <span className="inline-flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-[0.15em] text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Live
                        </span>
                    </div>

                    {/* Table */}
                    {logs.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-24 gap-3 text-slate-300">
                            <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center">
                                <Activity size={22} strokeWidth={1.5} className="text-slate-200" />
                            </div>
                            <div className="text-center">
                                <p className="text-sm font-semibold text-slate-400">No audit logs found</p>
                                <p className="text-[12px] mt-0.5">System events will appear here as they occur</p>
                            </div>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-[13px]">
                                <thead>
                                    <tr>
                                        {["Action", "Resource", "User", "Details", "Timestamp"].map((h, i) => (
                                            <th
                                                key={h}
                                                className={cn(
                                                    "px-5 py-3.5 text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.12em] bg-slate-50/80 border-b border-slate-100",
                                                    i === 4 ? "text-right" : "text-left"
                                                )}
                                            >
                                                {h}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                    {logs.map((log: any) => (
                                        <tr key={log.id} className="group hover:bg-slate-50/60 transition-colors">

                                            {/* Action */}
                                            <td className="px-5 py-4 whitespace-nowrap">
                                                <ActionBadge action={log.action} />
                                            </td>

                                            {/* Resource */}
                                            <td className="px-5 py-4">
                                                <span className="font-bold text-slate-700 text-[12px] uppercase tracking-wide">
                                                    {log.resource}
                                                </span>
                                            </td>

                                            {/* User */}
                                            <td className="px-5 py-4">
                                                <div className="flex items-center gap-1.5 text-[12px] text-slate-500 font-medium">
                                                    <UserIcon size={11} className="text-slate-300 shrink-0" />
                                                    <span className="font-mono text-[11px] text-slate-400">
                                                        {log.userId || "System"}
                                                    </span>
                                                </div>
                                            </td>

                                            {/* Details */}
                                            <td className="px-5 py-4 max-w-[220px]">
                                                <span className="font-mono text-[10.5px] text-slate-400 truncate block bg-slate-50 px-2 py-1 rounded-lg border border-slate-100">
                                                    {typeof log.details === "object"
                                                        ? JSON.stringify(log.details)
                                                        : log.details ?? "—"}
                                                </span>
                                            </td>

                                            {/* Timestamp */}
                                            <td className="px-5 py-4 text-right whitespace-nowrap">
                                                <div className="flex flex-col items-end">
                                                    <span className="text-[12px] font-bold text-slate-700 tabular-nums">
                                                        {new Date(log.createdAt).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
                                                    </span>
                                                    <span className="text-[10px] text-slate-400 font-medium tabular-nums">
                                                        {new Date(log.createdAt).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                                                    </span>
                                                </div>
                                            </td>

                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>

            </div>
        </div>
    )
}