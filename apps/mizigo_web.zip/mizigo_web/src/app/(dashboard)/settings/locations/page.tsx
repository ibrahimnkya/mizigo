import { MapPin, Globe, Building2, Phone, Plus, ArrowUpRight } from "lucide-react"
import { cn } from "@/lib/utils"

async function getLocations() {
    const res = await fetch("http://localhost:3000/api/locations", { cache: "no-store" })
    if (!res.ok) return []
    return res.json()
}

export default async function LocationsPage() {
    const locations = await getLocations()

    return (
        <div className="min-h-screen bg-[#f8f9fb]">
            <div className="max-w-[1520px] mx-auto px-6 lg:px-10 py-10 flex flex-col gap-8">

                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                    <div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full">
                                Infrastructure
                            </span>
                        </div>
                        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Terminal Locations</h1>
                        <p className="text-sm text-slate-400 font-medium mt-0.5">Manage operational stations and SGR terminal hubs.</p>
                    </div>
                    <button className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white text-[13px] font-extrabold px-5 py-2.5 rounded-xl shadow-lg shadow-slate-900/10 transition-all hover:-translate-y-0.5 active:translate-y-0 whitespace-nowrap">
                        <Plus size={14} strokeWidth={2.5} /> Add Station
                    </button>
                </div>

                {locations.length === 0 ? (
                    <div className="h-60 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-3 text-slate-300">
                        <MapPin size={32} strokeWidth={1.5} />
                        <p className="text-sm font-semibold text-slate-400">No terminal locations found</p>
                        <p className="text-[12px]">Add your first station to get started</p>
                    </div>
                ) : (
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        {locations.map((station: any) => (
                            <div
                                key={station.id}
                                className="group relative bg-white rounded-2xl border border-slate-100 p-5 shadow-[0_1px_3px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200 flex flex-col gap-4 overflow-hidden"
                            >
                                {/* Subtle glow */}
                                <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full blur-2xl opacity-[0.06] bg-sky-500 pointer-events-none" />

                                {/* Top row */}
                                <div className="flex items-start justify-between">
                                    <div className="w-9 h-9 bg-sky-50 rounded-xl flex items-center justify-center">
                                        <MapPin size={15} className="text-sky-600" strokeWidth={2.5} />
                                    </div>
                                    <span className={cn(
                                        "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border tracking-wide",
                                        station.isActive
                                            ? "bg-emerald-50 text-emerald-700 border-emerald-200/60"
                                            : "bg-rose-50 text-rose-700 border-rose-200/60"
                                    )}>
                                        <span className={cn("w-1.5 h-1.5 rounded-full", station.isActive ? "bg-emerald-500" : "bg-rose-500")} />
                                        {station.isActive ? "Operational" : "Closed"}
                                    </span>
                                </div>

                                {/* Name */}
                                <div>
                                    <h3 className="text-[15px] font-extrabold text-slate-900 tracking-tight group-hover:text-indigo-600 transition-colors">
                                        {station.name}
                                    </h3>
                                    <p className="text-[11px] font-mono font-bold text-slate-400 mt-0.5">Terminal {station.code}</p>
                                </div>

                                {/* Meta rows */}
                                <div className="flex flex-col gap-2">
                                    {station.region && (
                                        <div className="flex items-center gap-2 text-[12px] text-slate-500 font-medium">
                                            <Globe size={12} className="text-slate-300 shrink-0" />
                                            {station.region}
                                        </div>
                                    )}
                                    {station.phone && (
                                        <div className="flex items-center gap-2 text-[12px] text-slate-500 font-medium">
                                            <Phone size={12} className="text-slate-300 shrink-0" />
                                            {station.phone}
                                        </div>
                                    )}
                                </div>

                                {/* Footer */}
                                <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
                                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-300">View Details</span>
                                    <ArrowUpRight size={14} className="text-slate-200 group-hover:text-indigo-500 transition-colors" />
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}